#include <iostream>
#include <fstream>
#include <stack>
#include <sstream>
#include <string>
using namespace std;
#include <stdio.h>
#include<ctype.h>

string IntToPost(string input) 
{
    
    stack<char> num_Stack; // stack holding order of opertors 
    string postFix;  // new string 
    int length = input.length();
    
    for (int i = 0; i < length; i++) 
    {
        if (isdigit(input[i])) // Case 1: any operand is added to postfix string
        {
            postFix += input[i];
        } 
        else if (input[i] == '(') // Case 2: any open parenthesis is automatically added to stack
        {
            num_Stack.push(input[i]);
        } 
        else if (input[i] == ')') // Case 3: If an closed paranthesis is encountered, display and pop all operators between "(" and ")"
        {
            postFix += " "; // space to seperate all whole numbers and operators
            while (num_Stack.top() != '(') {
                postFix += num_Stack.top();
                num_Stack.pop();
            }
            num_Stack.pop();
        }
        else if (input[i] == '+' || input[i] == '-' || input[i] == '*' || input[i] == '/') // Case 4: An operator is encoutered, either add it to stack, or pop everthying with greater precedence and add to stack after
        {
            if (num_Stack.empty()) 
            {
                num_Stack.push(input[i]);
                postFix += " "; // space to seperate all whole numbers and operators
            } 
            else if (num_Stack.top() == '(') 
            {
                num_Stack.push(input[i]);
                postFix += " "; // space to seperate all whole numbers and operators
            } 
            else if (input[i] == '*' || input[i] == '/') // higher priority
            { 
                num_Stack.push(input[i]);
            } 
            else 
            {
                postFix += " "; // space to seperate all whole numbers and operators
                postFix += num_Stack.top();
                num_Stack.pop();
                num_Stack.push(input[i]);
            }
            postFix += " ";
        } 
    }
    while (!num_Stack.empty()) {
        postFix += " "; // space to seperate all whole numbers and operators
        if (num_Stack.top() == '(' || num_Stack.top() == ')')
        {
            cout << "Invalid expression" << endl;
        }
        postFix += num_Stack.top();
        num_Stack.pop();
    }
    return postFix;
}



int evaluatePostfix(string postFixed)
{
    
    stack<int> num_Stack;
    
    stringstream ss(postFixed);  // tokenizing string
    string token;
    
    
    while (ss >> token) {
        if (isdigit(token[0]))   
        {
            num_Stack.push(stoi(token));   // converting string to int 
        } 
        else 
        {
            int operand2 = num_Stack.top();  // keep track of operators 
            num_Stack.pop();
            int operand1 = num_Stack.top();  // keep track of operators 
            num_Stack.pop();
            int result;
            switch (token[0]) { 
                case '+':     // addition case 
                    result = operand1 + operand2;  
                    break;
                case '-':    // subtraction case
                    result = operand1 - operand2;
                    break;
                case '*':    // multiplication case 
                    result = operand1 * operand2;
                    break;
                case '/':    // division case 
                    result = operand1 / operand2;
                    break;
            }
            num_Stack.push(result);
        }
    }

    if (num_Stack.size() != 1) {
        cerr << "Invalid expression: " << postFixed << endl;   // if empty or not enough 
        return 0;
    }

    return num_Stack.top();
}
 











int main()
{
    string input, output, num;
    cout << "Please type the expression in the format of Infix Notation :" << endl;
    cin >> input;
    output = IntToPost(input);
    cout << "Postfixed:  " << output;
    cout << endl << "Result: " << evaluatePostfix(output);
    
    
    
}











